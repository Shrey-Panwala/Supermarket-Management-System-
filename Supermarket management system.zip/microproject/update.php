<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>UPDATE PRODUCT - Supermarket Management System</title>
    <style>
        /* Background with reduced opacity */
        body {
            position: relative;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            padding-top: 30px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('bg2.jpg') no-repeat center center fixed;
            background-size: cover;
            opacity: 0.9;
            z-index: -1;
        }

        /* Card */
        .card {
            max-width: 900px;
            width: 90%;
            padding: 50px;
            background: rgba(255, 255, 255, 0.85);
            border-radius: 20px;
            box-shadow: 0 4px 25px rgba(0, 0, 0, 0.3);
            transition: 0.4s;
            text-align: center;
            position: relative;
        }

        .card:hover {
            background: rgba(255, 255, 255, 0.95);
            transform: scale(1.01);
        }

        /* Title */
        h1 {
            font-size: 35px;
            font-weight: bold;
            font-family: 'Georgia', serif;
            text-transform: uppercase;
            margin-bottom: 30px;
            letter-spacing: 1px;
        }

        /* Back & Logout Buttons */
        .action-buttons {
            position: absolute;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
        }

        .btn-custom {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            background-color: gray;
            color: white;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background-color: black;
            opacity: 0.9;
            transform: translateY(-2px);
        }

        /* Table */
        table {
            margin: 20px auto;
            width: 100%;
            border-collapse: collapse;
            font-size: 18px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            background: white;
        }

        .te {
            font-weight: bold;
            background: gray;
            color: white;
            font-size: 18px;
        }

        /* Update Button */
        .btn {
            text-decoration: none;
            padding: 8px 16px;
            background-color: gray;
            color: white;
            border-radius: 8px;
            transition: 0.3s;
            display: inline-block;
        }

        .btn:hover {
            background-color: black;
            opacity: 0.9;
            transform: translateY(-2px);
        }

        /* Smooth transitions */
        * {
            transition: all 0.3s ease-in-out;
        }
    </style>
</head>

<body>

    <div class="card">

        <!-- BACK + LOGOUT -->
        <div class="action-buttons">
            <button class="btn-custom" onclick="goBack()">BACK</button>
            <form method="POST" style="display: inline;">
                <input type="submit" class="btn-custom" name="logout" value="LOGOUT">
            </form>
        </div>

        <script>
            function goBack() {
                window.location.href = 'menu.php';
            }
        </script>

        <?php
        if (isset($_POST["logout"])) {
            session_destroy();
            echo "<script>window.location.href = 'index.php';</script>";
            exit();
        }
        ?>

        <!-- TITLE -->
        <h1>UPDATE PRODUCT</h1>

        <!-- PRODUCT TABLE -->
        <?php
        include "config.php";
        $sql = "SELECT * FROM info;";
        $result = mysqli_query($conn, $sql);
        echo "<table>
            <tr>
                <td class='te'>ID</td>
                <td class='te'>NAME</td>  
                <td class='te'>PRICE</td>       
                <td class='te'>AVAILABLE</td>
                <td class='te'>DISCOUNT</td>
                <td class='te'>ACTION</td>
            </tr>";

        while ($array = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $array[0] . "</td>";
            echo "<td>" . $array[1] . "</td>";
            echo "<td>" . $array[2] . "</td>";
            echo "<td>" . $array[3] . "</td>";
            echo "<td>" . $array[4] . "</td>";
            echo "<td><a class='btn' href='update1.php?ide=" . $array[0] . "'>Update</a></td>";
            echo "</tr>";
        }
        echo "</table>";
        ?>

    </div>

</body>

</html>
