<?php
session_start();
include 'config.php';

if (isset($_POST["back"])) {
    header("Location: menu.php");
    exit();
}
if (isset($_POST["logout"])) {
    session_destroy();
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>DELETE PRODUCT - Supermarket Management System</title>
    <style>
    /* Background */
    body {
    position: relative;
    margin: 0;
    padding: 0;
    height: 100vh;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding-top: 30px;
}

body::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url('bg2.jpg') no-repeat center center fixed;
    background-size: cover;
    opacity: 0.9; /* Adjust opacity (0.0 to 1.0) */
    z-index: -1;
}


        /* Card */
        .delete-card {
            width: 55%;
            max-width: 800px;
            padding: 50px;
            background: rgba(255, 255, 255, 0.85);
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            transition: 0.4s;
            text-align: center;
            position: relative;
        }

        .delete-card:hover {
            background: rgba(255, 255, 255, 0.95);
            transform: scale(1.01);
        }

        /* Header */
        h1 {
            font-family: 'Georgia', serif;
            font-size: 34px;
            font-weight: bold;
            margin-bottom: 25px;
        }

        /* Back & Logout buttons */
        .action-buttons {
            position: absolute;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
        }

        .btn-custom {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            background-color: gray;
            color: white;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background-color: black;
            opacity: 0.9;
            transform: translateY(-2px);
        }

        /* Table */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ccc;
            font-size: 18px;
        }

        th {
            background-color: lightgray;
            color: black;
            border-radius: 5px;
        }

        /* Delete Button */
        .delete-link {
            padding: 8px 16px;
            background: gray;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            transition: 0.3s;
        }

        .delete-link:hover {
            background: black;
            opacity: 0.9;
            transform: translateY(-2px);
        }

        /* DELETE ALL button */
        .delete-all-btn {
            margin-top: 20px;
            padding: 12px 30px;
            font-size: 18px;
            border: none;
            border-radius: 8px;
            background-color: gray;
            color: white;
            cursor: pointer;
            transition: 0.3s;
        }

        .delete-all-btn:hover {
            background-color: black;
            opacity: 0.9;
            transform: translateY(-2px);
        }

        /* Responsive */
        @media(max-width:768px) {
            .delete-card {
                width: 90%;
                padding: 30px;
            }
            th, td {
                font-size: 14px;
                padding: 10px;
            }
            .delete-all-btn, .btn-custom {
                font-size: 14px;
                padding: 8px 15px;
            }
        }

        /* Smooth transition */
        * {
            transition: all 0.3s ease-in-out;
        }

    </style>
</head>

<body>

    <div class="delete-card">

        <!-- BACK & LOGOUT -->
        <div class="action-buttons">
            <form method="POST" style="display: flex; gap: 10px;">
                <input type="submit" class="btn-custom" name="back" value="BACK">
                <input type="submit" class="btn-custom" name="logout" value="LOGOUT">
            </form>
        </div>

        <h1>DELETE PRODUCTS</h1>

        <form method="POST">
            <table>
                <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>PRICE</th>
                    <th>AVAILABLE</th>
                    <th>DISCOUNT</th>
                    <th>ACTION</th>
                </tr>

                <?php
                $sql = "SELECT * FROM info";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($array = mysqli_fetch_array($result)) {
                        echo "<tr>";
                        echo "<td>" . $array[0] . "</td>";
                        echo "<td>" . $array[1] . "</td>";
                        echo "<td>" . $array[2] . "</td>";
                        echo "<td>" . $array[3] . "</td>";
                        echo "<td>" . $array[4] . "</td>";
                        echo "<td><a class='delete-link' href='delete.php?ide=" . $array[0] . "'>Delete</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>NO DATA FOUND!!</td></tr>";
                }
                ?>
            </table>

            <?php if (mysqli_num_rows($result) > 0) { ?>
                <input type="submit" name="submit" class="delete-all-btn" value="DELETE ALL RECORDS">
            <?php } ?>
        </form>

        <?php
        if (isset($_POST['submit'])) {
            $q = "DROP TABLE info";
            if (mysqli_query($conn, $q)) {
                echo "<script>alert('ALL RECORDS DELETED!!'); window.location.href = 'menu.php';</script>";
                exit();
            } else {
                echo "<script>alert('FAILED TO DELETE!!');</script>";
            }
        }

        if (isset($_GET['ide'])) {
            $id = $_GET["ide"];
            $q = mysqli_query($conn, "DELETE FROM info WHERE id=$id");
            if ($q) {
                echo "<script>alert('ITEM DELETED!!'); window.location.href = 'menu.php';</script>";
                exit();
            } else {
                echo "<script>alert('ITEM NOT DELETED!!');</script>";
            }
        }
        ?>

    </div>

</body>

</html>
