<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Insert Product - Supermarket Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

    <style>
        .insert-card {
            max-width: 800px;
            margin: 80px auto;
            padding: 50px;
            background: rgba(255, 255, 255, 0.85);
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            transition: 0.4s;
            text-align: center;
            position: relative;
        }

        .insert-card:hover {
            background: rgba(255, 255, 255, 0.95);
            transform: scale(1.01);
        }

        .action-buttons {
            position: absolute;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
        }

        .btn-custom {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            background-color: gray;
            color: white;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background-color: black;
            opacity: 0.9;
            transform: translateY(-2px);
        }

        h1 {
          font-family: 'Georgia', serif;
          font-size: 38px;
          color: #333;
          margin-top: 30px;
          margin-bottom: 35px;
          text-transform: uppercase;
          letter-spacing: 1px;
          font-weight: bold; /* <-- added */
          }


        .field-group {
            margin-bottom: 25px; /* slightly increased */
            text-align: left;
        }

        .label-cell {
            display: inline-block;
            background: gray;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 20px;
            margin-bottom: 10px; /* slightly increased */
        }

        .input-cell input {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            font-size: 18px;
            box-sizing: border-box;
        }

        .submit-btn {
            padding: 15px 40px;
            font-size: 22px;
            border: none;
            border-radius: 8px;
            background-color: gray;
            color: white;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 30px; /* added more breathing space */
        }

        .submit-btn:hover {
            background-color: black;
            opacity: 0.9;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .insert-card {
                padding: 30px;
            }

            h1 {
                font-size: 28px;
            }

            .label-cell {
                font-size: 18px;
            }

            .btn-custom, .submit-btn {
                font-size: 14px;
                padding: 10px 15px;
            }
        }
    </style>
</head>

<body class="bg-light">

    <div class="container">
        <div class="insert-card">

            <!-- BACK + LOGOUT -->
            <div class="action-buttons">
                <form method="POST" style="display: flex; gap: 10px;">
                    <input type="submit" class="btn-custom" name="back" value="BACK">
                    <input type="submit" class="btn-custom" name="logout" value="LOGOUT">
                </form>
            </div>

            <?php
            if (isset($_POST["back"])) {
                header("location:menu.php");
            }
            if (isset($_POST["logout"])) {
                session_destroy();
                header("location:index.php");
            }
            ?>

            <!-- TITLE -->
            <h1>Insert Product</h1>

            <!-- FORM -->
            <form method="POST">

                <div class="field-group">
                    <div class="label-cell">Name</div>
                    <div class="input-cell"><input type="text" name="name" required></div>
                </div>

                <div class="field-group">
                    <div class="label-cell">Price</div>
                    <div class="input-cell"><input type="number" name="price" required></div>
                </div>

                <div class="field-group">
                    <div class="label-cell">No. of item</div>
                    <div class="input-cell"><input type="number" name="no" required></div>
                </div>

                <div class="field-group">
                    <div class="label-cell">Discount</div>
                    <div class="input-cell"><input type="number" name="discount" required></div>
                </div>

                <input type="submit" class="submit-btn" name="submit" value="INSERT">

            </form>

        </div>
    </div>

    <?php
    if (isset($_POST['submit'])) {
        include 'config.php';
        $nm = $_POST['name'];
        $p = $_POST['price'];
        $n = $_POST['no'];
        $d = $_POST['discount'];
        $sql = "INSERT INTO info VALUES('','$nm','$p','$n','$d')";
        $q = mysqli_query($conn, $sql);
        if ($q) {
            echo "<script>alert('ITEM ADDED!!'); window.location.href = 'menu.php';</script>";
        } else {
            echo "<script>alert('ITEM NOT ADDED!!');</script>";
        }
    }
    ?>

</body>

</html>
