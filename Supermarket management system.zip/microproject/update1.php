<?php
include 'config.php';
session_start();

if (!isset($_GET['ide'])) {
    echo "<script>alert('Invalid request!'); window.location.href = 'update.php';</script>";
    exit();
}

$id = $_GET['ide'];
$_SESSION['id'] = $id;
$sql = "SELECT * FROM info WHERE id = $id";
$result = mysqli_query($conn, $sql);
$res = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>UPDATE PRODUCT</title>
    <style>
        /* Background */
        body {
            position: relative;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('bg2.jpg') no-repeat center center fixed;
            background-size: cover;
            opacity: 0.9;
            z-index: -1;
        }

        /* Card */
        .card {
            max-width: 600px;
            width: 90%;
            padding: 40px;
            background: rgba(255, 255, 255, 0.85);
            border-radius: 20px;
            box-shadow: 0 4px 25px rgba(0, 0, 0, 0.3);
            transition: 0.4s;
            text-align: center;
            position: relative;
        }

        .card:hover {
            background: rgba(255, 255, 255, 0.95);
            transform: scale(1.01);
        }

        /* Title */
        h1 {
            font-size: 28px;
            font-weight: bold;
            font-family: 'Georgia', serif;
            margin-bottom: 25px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Back & Logout Buttons */
        .action-buttons {
            position: absolute;
            top: 15px;
            right: 15px;
            display: flex;
            gap: 10px;
        }

        .btn-custom {
            padding: 8px 18px;
            font-size: 14px;
            border: none;
            border-radius: 8px;
            background-color: gray;
            color: white;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background-color: black;
            opacity: 0.9;
            transform: translateY(-2px);
        }

        /* Table */
        table {
            margin: 0 auto;
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
        }

        td {
            padding: 8px;
        }

        .te {
            font-weight: bold;
            background: gray;
            color: white;
            border-radius: 5px;
            padding: 8px;
        }

        /* Input Fields */
        .in input {
            width: 90%;
            padding: 8px;
            border: 1px solid gray;
            border-radius: 5px;
            transition: 0.3s;
            font-size: 15px;
        }

        .in input:focus {
            outline: none;
            border-color: black;
            transform: scale(1.02);
        }

        /* Submit Button */
        .btn {
            padding: 10px 25px;
            font-size: 15px;
            background-color: gray;
            color: white;
            border: none;
            border-radius: 8px;
            transition: 0.3s;
            cursor: pointer;
        }

        .btn:hover {
            background-color: black;
            opacity: 0.9;
            transform: translateY(-2px);
        }

        /* Smooth transitions */
        * {
            transition: all 0.3s ease-in-out;
        }
    </style>
</head>

<body>

    <div class="card">

        <!-- BACK + LOGOUT -->
        <div class="action-buttons">
            <button class="btn-custom" onclick="goBack()">BACK</button>
            <form method="POST" style="display: inline;">
                <input type="submit" class="btn-custom" name="logout" value="LOGOUT">
            </form>
        </div>

        <script>
            function goBack() {
                window.location.href = 'update.php';
            }
        </script>

        <?php
        if (isset($_POST["logout"])) {
            session_destroy();
            echo "<script>window.location.href = 'login.php';</script>";
            exit();
        }
        ?>

        <!-- FORM -->
        <h1>UPDATE PRODUCT</h1>

        <form method="POST">
            <table>
                <tr>
                    <td class="te">Name</td>
                    <td class="in"><input type="text" name="name" value="<?php echo htmlspecialchars($res[1]); ?>" required></td>
                </tr>
                <tr>
                    <td class="te">Price</td>
                    <td class="in"><input type="number" name="price" value="<?php echo htmlspecialchars($res[2]); ?>" required></td>
                </tr>
                <tr>
                    <td class="te">No. of Items</td>
                    <td class="in"><input type="number" name="no" value="<?php echo htmlspecialchars($res[3]); ?>" required></td>
                </tr>
                <tr>
                    <td class="te">Discount</td>
                    <td class="in"><input type="number" name="discount" value="<?php echo htmlspecialchars($res[4]); ?>" required></td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><input type="submit" class="btn" name="submit" value="UPDATE"></td>
                </tr>
            </table>
        </form>

    </div>

</body>

</html>

<?php
if (isset($_POST['submit'])) {
    $nm = mysqli_real_escape_string($conn, $_POST['name']);
    $p = (float) $_POST['price'];
    $n = (int) $_POST['no'];
    $d = (float) $_POST['discount'];
    $i = $_SESSION["id"];

    $sql = "UPDATE info SET name='$nm', price='$p', num='$n', discount='$d' WHERE id='$i'";
    $q = mysqli_query($conn, $sql);

    if ($q) {
        echo "<script>alert('ITEM UPDATED!!'); window.location.href = 'menu.php';</script>";
    } else {
        echo "<script>alert('ITEM NOT UPDATED!!');</script>";
    }
}
?>
