<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PRODUCT LIST - Supermarket Management System</title>
    <style>
        /* Background with reduced opacity */
        body {
            position: relative;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            padding-top: 30px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('bg2.jpg') no-repeat center center fixed;
            background-size: cover;
            opacity: 0.9;
            z-index: -1;
        }

        /* Card */
        .card {
            max-width: 800px;
            width: 90%;
            padding: 50px;
            background: rgba(255, 255, 255, 0.85);
            border-radius: 20px;
            box-shadow: 0 4px 25px rgba(0, 0, 0, 0.3);
            transition: 0.4s;
            text-align: center;
            position: relative;
        }

        .card:hover {
            background: rgba(255, 255, 255, 0.95);
            transform: scale(1.015);
        }

        /* Title */
        h1 {
            font-size: 35px;
            font-family: 'Georgia', serif;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 30px;
            letter-spacing: 1px;
        }

        /* Back & Logout Buttons */
        .action-buttons {
            position: absolute;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
        }

        .btn-custom {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            background-color: gray;
            color: white;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background-color: black;
            opacity: 0.9;
            transform: translateY(-2px);
        }

        /* Table */
        table {
            margin: 20px auto;
            width: 100%;
            border-collapse: collapse;
            font-size: 18px;
        }

        th {
            background: gray;
            color: white;
            padding: 10px;
            text-transform: uppercase;
        }

        td {
            border: 1px solid #ccc;
            padding: 10px;
            background: white;
        }

        .te {
            font-weight: bold;
            background: gray;
            color: white;
            font-size: 18px;
        }

        .no-record {
            color: red;
            font-size: 20px;
            margin-top: 15px;
        }

        /* Smooth transitions */
        * {
            transition: all 0.3s ease-in-out;
        }
    </style>
</head>

<body>

    <div class="card">

        <!-- BACK + LOGOUT -->
        <div class="action-buttons">
            <button class="btn-custom" onclick="goBack()">BACK</button>
            <form method="POST" style="display: inline;">
                <input type="submit" class="btn-custom" name="logout" value="LOGOUT">
            </form>
        </div>

        <script>
            function goBack() {
                window.location.href = 'menu.php';
            }
        </script>

        <?php
        if (isset($_POST["logout"])) {
            session_destroy();
            echo "<script>window.location.href = 'index.php';</script>";
            exit();
        }
        ?>

        <!-- TITLE -->
        <h1>PRODUCT LIST</h1>

        <!-- PRODUCT DISPLAY -->
        <?php
        $t = 0;
        include "config.php";
        $sql = "SELECT * FROM info";
        $result = mysqli_query($conn, $sql);

        while ($array = mysqli_fetch_array($result)) {
            $t++;
            echo "<table>";
            echo "<tr><th colspan='2'>ITEM: $t</th></tr>";
            echo "<tr><td class='te'>ID</td><td>" . $array[0] . "</td></tr>";
            echo "<tr><td class='te'>NAME</td><td>" . $array[1] . "</td></tr>";
            echo "<tr><td class='te'>PRICE</td><td>" . $array[2] . "</td></tr>";
            echo "<tr><td class='te'>QUANTITY</td><td>" . $array[3] . "</td></tr>";
            echo "<tr><td class='te'>DISCOUNT</td><td>" . $array[4] . "</td></tr>";
            echo "</table><br>";
        }
        if ($t == 0) {
            echo "<p class='no-record'>NO RECORD FOUND!!</p>";
        }
        ?>

    </div>

</body>

</html>
