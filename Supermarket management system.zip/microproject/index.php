<?php
session_start(); 
$error = "";
if (isset($_POST['submit'])) {
    if ($_POST['uname'] == "Admin" && $_POST['psw'] == "admin") {
        $_SESSION['uname'] = 'Admin';
        $_SESSION['psw'] = 'admin';
        header("location:menu.php");
        exit();
    } else {
        $error = "Please enter valid username and password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supermarket Management System - Login</title>

    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
    font-family: Helvetica;
    background: url('bg2.jpg') no-repeat center center fixed;
    background-size: cover;
    margin: 0;
    padding: 0;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
}

/* Light overlay to make background image lighter */
body::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.13); /* Adjust transparency (0.1 to 0.5 for lighter effect) */
    z-index: -1;
}

/* Ensure background is responsive on smaller screens */
@media screen and (max-width: 768px) {
    body {
        background-size: cover;
        background-attachment: scroll; /* Prevents zoom-in issues on mobile */
    }

    body::before {
        background: rgba(255, 255, 255, 0.5); /* Slightly increase lightness on smaller screens */
    }
}

@media screen and (max-width: 480px) {
    body {
        background-size: contain; /* Ensures full image visibility */
        background-position: center top;
    }
}
        .login-card {
            background: rgba(255, 255, 255, 0.85);
            border: 6px solid blue;
            border-radius: 15px;
            padding: 50px;
            width: 100%;
            max-width: 700px;
            box-shadow: 0 10px 20px rgba(165, 230, 237, 0.4);
            animation: fadeIn 1s ease;
            backdrop-filter: blur(8px);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            font-family: 'Georgia', serif;
            font-size: 60px;
            font-weight: bold;
            text-shadow: 3px 3px 8px rgba(0,0,0,0.6);
            color: #1f3c88;
            letter-spacing: 2px;
        }

        input[type=text], input[type=password] {
            width: 80%;
            padding: 12px 20px;
            margin: 12px 0;
            display: inline-block;
            border: 2px solid black;
            box-sizing: border-box;
            border-radius: 8px;
        }

        input[type=text]:focus, input[type=password]:focus {
            border-color: #04AA6D;
            outline: none;
            box-shadow: 0 0 5px #04AA6D;
        }

        button {
            background-color: #04AA6D;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
            border-radius: 8px;
            transition: all 0.4s ease;
        }

        button:hover {
            color: white;
            background-color: black;
            transform: scale(1.02);
        }

        .imgcontainer {
            text-align: center;
            margin-bottom: 20px;
        }

        img {
            border-radius: 50%;
            border: 0px solid black;
            width: 200px;
            height: 200px;
        }

        .tz {
            color: white;
            background-color: red;
            font-size: 18px;
            padding: 5px 10px;
            display: inline-block;
            border-radius: 4px;
            margin-bottom: 5px;
        }

        .container label {
            display: block;
            margin-top: 15px;
        }

        .error-msg {
            color: red;
            margin-top: 10px;
            font-size: 14px;
        }

        @media screen and (max-width: 576px) {
            .login-card {
                margin: 20px;
                padding: 20px;
            }

            img {
                width: 150px;
                height: 150px;
            }

            input[type=text], input[type=password] {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <div class="login-card">
        <h2 class="text-center mb-3"><i class="bi bi-basket2-fill"></i> SUPERMARKET LOGIN</h2>
        <form method="post">
            <div class="imgcontainer">
                <img src="cropped_image.png" alt="Profile Image">
            </div>

            <div class="container text-center">
                <label for="uname" class="tz"><b>Username</b></label>
                <input type="text" placeholder="Enter Username" name="uname" required>

                <label for="psw" class="tz"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="psw" required>

                <button type="submit" name="submit">Login</button>

                <div class="form-check mt-3">
                    <input type="checkbox" checked class="form-check-input" name="remember" id="remember">
                    <label class="form-check-label tz" for="remember"><b>Remember me</b></label>
                </div>

                <?php if ($error != "") { echo '<div class="error-msg">'.$error.'</div>'; } ?>

            </div>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
