<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Supermarket Management System</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .logout-back {
            position: absolute;
            top: 25px;
            right: 25px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .logout-back .bt {
            padding: 9px 18px;
            font-size: 15px;
            border: none;
            border-radius: 7px;
            background-color: gray;
            color: white;
            cursor: pointer;
            transition: 0.3s;
            font-family: 'Georgia', serif;
            font-weight: bold;
            white-space: nowrap;
        }

        .logout-back .bt:hover {
            background-color: black;
            opacity: 0.9;
            transform: scale(1.05);
        }

        h1 {
            font-family: 'Georgia', serif;
            font-size: 38px;
            color: black;
            margin-bottom: 35px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .menu-btn {
            width: 85%;
            max-width: 520px;
            height: 65px;
            font-size: 22px;
            margin: 18px auto;
            border: none;
            border-radius: 12px;
            background-color: gray;
            color: white;
            cursor: pointer;
            display: block;
            transition: 0.3s;
            letter-spacing: 1px;
            font-weight: bold;
            font-family: 'Georgia', serif;
        }

        .menu-btn:hover {
            background-color: black;
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        @media (max-width: 768px) {
            .admin-card {
                width: 90%;
                padding: 35px;
            }

            .menu-btn {
                width: 100%;
            }

            .logout-back {
                top: 15px;
                right: 15px;
                flex-direction: column;
                align-items: flex-end;
                gap: 5px;
            }
        }
    </style>
</head>

<body>

    <div class="admin-card">

        <div class="logout-back">
            <form method="POST" style="display: flex; gap: 10px; flex-wrap: wrap;">
                <input type="submit" class="bt" name="back" value="BACK">
                <input type="submit" class="bt" name="logout" value="LOGOUT">
            </form>
        </div>

        <?php
        if (isset($_POST["back"])) {
            header("location:index.php");
        }
        if (isset($_POST["logout"])) {
            session_destroy();
            header("location:index.php");
        }
        ?>

        <h1>Admin Panel</h1>
        <form method="post">
            <input type="submit" class="menu-btn" value="INSERT" name="insert">
            <input type="submit" class="menu-btn" value="UPDATE" name="update">
            <input type="submit" class="menu-btn" value="DELETE" name="delete">
            <input type="submit" class="menu-btn" value="SEARCH" name="search">
            <input type="submit" class="menu-btn" value="DISPLAY" name="display">
        </form>
    </div>

    <?php
    if (isset($_POST["insert"])) {
        header("location:insert.php");
    }
    if (isset($_POST["update"])) {
        header("location:update.php");
    }
    if (isset($_POST["delete"])) {
        header("location:delete.php");
    }
    if (isset($_POST["search"])) {
        header("location:search.php");
    }
    if (isset($_POST["display"])) {
        header("location:display.php");
    }
    ?>
</body>

</html>
